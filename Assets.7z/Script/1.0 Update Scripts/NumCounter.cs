﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumCounter : MonoBehaviour
{

   public void C_NumberCount(int nInit, int nValue, ref int nResult)
    {
        nResult = nInit + nValue;
    }


}
